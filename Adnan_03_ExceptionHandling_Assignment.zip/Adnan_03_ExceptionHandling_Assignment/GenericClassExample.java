// GenericClassExample.java

/**
 "GenericClassExample"
 * <p>Author: Adnan Shaikh</p>
 * <p>Roll No: 03</p>
 * <p>Start Date: 23/10/2024</p>
 * <p>Modified Date: 23/10/2024</p>
 */
public class GenericClassExample<T> {
    private T element;

    public GenericClassExample(T element) {
        this.element = element;
    }

    public T getElement() {
        return element;
    }

    public static void main(String[] args) {
        GenericClassExample<String> stringInstance = new GenericClassExample<>("Hello, Generics!");
        System.out.println("String Element: " + stringInstance.getElement());

        GenericClassExample<Integer> integerInstance = new GenericClassExample<>(123);
        System.out.println("Integer Element: " + integerInstance.getElement());
    }
}

// LambdaFunctionExample.java

/**
  "LambdaFunctionExample"
 * <p>Author: Adnan Shaikh</p>
 * <p>Roll No: 03</p>
 * <p>Start Date: 23/10/2024</p>
 * <p>Modified Date: 23/10/2024</p>
 */

import java.util.Arrays;
import java.util.List;

public class LambdaFunctionExample {
    public static void main(String[] args) {
        List<String> names = Arrays.asList("Gaurav", "Aniruddh", "Charlie");

        // Using a lambda function to print each name
        names.forEach(name -> System.out.println("Hello, " + name + "!"));
    }
}
